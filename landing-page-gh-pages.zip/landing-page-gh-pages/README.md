# Growth Landing Page 

New Growth Homepage base on My favorite OS OpenSUSE's Homepage [https://github.com/openSUSE/landing-page](https://github.com/openSUSE/landing-page)

View: [http://growth.ren/](http://growth.ren/)

Setup
---

1.Install

```
npm install
```

2.Run

```
gulp
```

MIT
---

Copyright (c) 2015 The openSUSE Project
